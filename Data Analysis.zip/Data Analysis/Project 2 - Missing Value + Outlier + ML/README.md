EDA + Missing values and Outliers - Detection and Treatment + Model Building











Dataset Description


An individual’s annual income results from various factors. Intuitively, it is influenced by the individual’s education level, age, gender, 
occupation, etc.

This is a widely cited KNN dataset. I encountered it during my course, and I wish to share it here because it is a good starter example for 
data pre-processing and machine learning practices.

Fields The dataset contains 16 columns

Target filed: Income -- The income is divided into two classes: <=50K and >50K

Number of attributes: 14
